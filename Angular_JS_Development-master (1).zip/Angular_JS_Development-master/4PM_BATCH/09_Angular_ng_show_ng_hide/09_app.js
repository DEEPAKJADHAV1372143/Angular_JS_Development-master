// Create a module
var app = angular.module('HBSApp',[]);

// Create a Controller
app.controller('HBSAppCtrl',function() {
    this.eating = null;
    this.coding = null;
    this.sleeping = null;
});